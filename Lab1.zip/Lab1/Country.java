import java.util.* ;

public class Country extends Place {
  private String language;

  //getters
  public String getLanguate(){
    return language;
  }

  //setters
  public void setLanguage(String newLanguage){
    language = newLanguage;
  }
}
